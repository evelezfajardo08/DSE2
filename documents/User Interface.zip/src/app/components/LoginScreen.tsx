import { useState } from 'react';
import { Bot, GraduationCap, User, Eye, EyeOff, ArrowRight, BookOpen, Trophy, Users, ChevronLeft } from 'lucide-react';

type Role = 'student' | 'teacher';
type AuthMode = 'role-select' | 'login' | 'register';

interface LoginScreenProps {
  onLogin: (role: Role, userData: { name: string; email: string }) => void;
}

const STUDENT_FEATURES = [
  { icon: Bot, text: 'Chatbot mentor personalizado' },
  { icon: Trophy, text: 'Sistema de logros y progreso' },
  { icon: BookOpen, text: 'Actividades de liderazgo' },
];

const TEACHER_FEATURES = [
  { icon: Users, text: 'Panel de seguimiento grupal' },
  { icon: Trophy, text: 'Reportes de desempeño' },
  { icon: BookOpen, text: 'Gestión de cursos y grupos' },
];

export function LoginScreen({ onLogin }: LoginScreenProps) {
  const [authMode, setAuthMode] = useState<AuthMode>('role-select');
  const [role, setRole] = useState<Role>('student');
  const [isLogin, setIsLogin] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const [form, setForm] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    institution: '',
    subject: '',
    studentId: '',
    career: '',
  });

  const handleField = (field: string, value: string) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const handleRoleSelect = (selected: Role) => {
    setRole(selected);
    setAuthMode('login');
    setIsLogin(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const name = isLogin ? form.email.split('@')[0] : form.name;
    onLogin(role, { name, email: form.email });
  };

  const features = role === 'student' ? STUDENT_FEATURES : TEACHER_FEATURES;
  const roleLabel = role === 'student' ? 'Estudiante' : 'Docente';
  const roleColor = role === 'student' ? 'from-blue-600 to-blue-800' : 'from-indigo-700 to-purple-800';
  const accentColor = role === 'student' ? 'bg-yellow-400' : 'bg-purple-400';

  if (authMode === 'role-select') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#1E3A8A] via-[#1e4fa8] to-[#1a2f6e] flex flex-col items-center justify-center p-4">
        {/* Decorative circles */}
        <div className="absolute top-0 left-0 w-96 h-96 bg-white/5 rounded-full -translate-x-1/2 -translate-y-1/2 pointer-events-none" />
        <div className="absolute bottom-0 right-0 w-80 h-80 bg-[#FACC15]/10 rounded-full translate-x-1/3 translate-y-1/3 pointer-events-none" />

        <div className="relative z-10 w-full max-w-xl">
          {/* Logo */}
          <div className="flex flex-col items-center mb-10">
            <div className="w-20 h-20 bg-white rounded-2xl flex items-center justify-center shadow-2xl mb-4">
              <Bot className="w-11 h-11 text-[#1E3A8A]" />
            </div>
            <h1 className="text-4xl font-bold text-white tracking-tight">LideraBot</h1>
            <p className="text-blue-200 mt-1 text-center">Tu asistente virtual para desarrollar liderazgo</p>
          </div>

          {/* Role Cards */}
          <p className="text-center text-white/70 text-sm mb-6 uppercase tracking-widest font-medium">
            ¿Cómo quieres ingresar?
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Student Card */}
            <button
              onClick={() => handleRoleSelect('student')}
              className="group bg-white/10 hover:bg-white/20 border border-white/20 hover:border-[#FACC15]/60 rounded-2xl p-6 text-left transition-all duration-300 hover:scale-105 hover:shadow-2xl"
            >
              <div className="w-12 h-12 bg-[#FACC15] rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <User className="w-6 h-6 text-[#1E3A8A]" />
              </div>
              <h3 className="text-white font-semibold text-lg mb-1">Soy Estudiante</h3>
              <p className="text-blue-200 text-sm leading-relaxed">
                Desarrolla habilidades de liderazgo con tu mentor virtual personalizado.
              </p>
              <div className="mt-4 flex items-center gap-2 text-[#FACC15] text-sm font-medium">
                Comenzar
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </button>

            {/* Teacher Card */}
            <button
              onClick={() => handleRoleSelect('teacher')}
              className="group bg-white/10 hover:bg-white/20 border border-white/20 hover:border-purple-400/60 rounded-2xl p-6 text-left transition-all duration-300 hover:scale-105 hover:shadow-2xl"
            >
              <div className="w-12 h-12 bg-purple-400 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <GraduationCap className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-white font-semibold text-lg mb-1">Soy Docente</h3>
              <p className="text-blue-200 text-sm leading-relaxed">
                Monitorea el progreso de tus estudiantes y gestiona grupos académicos.
              </p>
              <div className="mt-4 flex items-center gap-2 text-purple-300 text-sm font-medium">
                Comenzar
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>
            </button>
          </div>

          <p className="text-center text-white/40 text-xs mt-8">
            Plataforma educativa para el desarrollo de competencias de liderazgo
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F3F4F6] flex">
      {/* Left panel — branding */}
      <div className={`hidden lg:flex flex-col justify-between w-[420px] bg-gradient-to-b ${roleColor} p-10 relative overflow-hidden`}>
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full translate-x-1/2 -translate-y-1/2" />
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-white/5 rounded-full -translate-x-1/3 translate-y-1/3" />

        <div className="relative z-10">
          <button
            onClick={() => setAuthMode('role-select')}
            className="flex items-center gap-2 text-white/60 hover:text-white text-sm mb-10 transition-colors"
          >
            <ChevronLeft className="w-4 h-4" />
            Cambiar tipo de acceso
          </button>
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center shadow-lg">
              <Bot className="w-7 h-7 text-[#1E3A8A]" />
            </div>
            <div>
              <div className="text-white font-bold text-xl leading-none">LideraBot</div>
              <div className="text-white/60 text-xs mt-0.5">Asistente virtual educativo</div>
            </div>
          </div>

          <div className={`inline-flex items-center gap-2 ${accentColor} text-[#1E3A8A] text-xs font-bold px-3 py-1.5 rounded-full mb-6`}>
            {role === 'student' ? <User className="w-3.5 h-3.5" /> : <GraduationCap className="w-3.5 h-3.5" />}
            Acceso {roleLabel}
          </div>

          <h2 className="text-3xl font-bold text-white leading-tight mb-3">
            {role === 'student'
              ? 'Desarrolla tu potencial de liderazgo'
              : 'Gestiona y potencia a tus estudiantes'}
          </h2>
          <p className="text-white/70 text-sm leading-relaxed">
            {role === 'student'
              ? 'Aprende, practica y mide tu crecimiento con un mentor virtual adaptado a ti.'
              : 'Visualiza el progreso de tu grupo, personaliza actividades y genera reportes académicos.'}
          </p>
        </div>

        <div className="relative z-10 space-y-3">
          {features.map(({ icon: Icon, text }) => (
            <div key={text} className="flex items-center gap-3">
              <div className="w-8 h-8 bg-white/15 rounded-lg flex items-center justify-center flex-shrink-0">
                <Icon className="w-4 h-4 text-white" />
              </div>
              <span className="text-white/80 text-sm">{text}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Right panel — form */}
      <div className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-md">
          {/* Mobile back + brand */}
          <div className="lg:hidden mb-6">
            <button
              onClick={() => setAuthMode('role-select')}
              className="flex items-center gap-1 text-[#1E3A8A] text-sm mb-4 font-medium"
            >
              <ChevronLeft className="w-4 h-4" />
              Volver
            </button>
            <div className="flex items-center gap-2 mb-1">
              <div className="w-8 h-8 bg-[#1E3A8A] rounded-lg flex items-center justify-center">
                <Bot className="w-5 h-5 text-white" />
              </div>
              <span className="font-bold text-[#1E3A8A] text-lg">LideraBot</span>
            </div>
          </div>

          {/* Tab switcher */}
          <div className="bg-white rounded-2xl shadow-lg p-1 flex mb-6">
            <button
              onClick={() => setIsLogin(true)}
              className={`flex-1 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                isLogin
                  ? 'bg-[#1E3A8A] text-white shadow-md'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              Iniciar Sesión
            </button>
            <button
              onClick={() => setIsLogin(false)}
              className={`flex-1 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                !isLogin
                  ? 'bg-[#1E3A8A] text-white shadow-md'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              Registrarse
            </button>
          </div>

          <div className="bg-white rounded-2xl shadow-lg p-8">
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-gray-900">
                {isLogin ? `Bienvenido/a de vuelta` : `Crear cuenta`}
              </h2>
              <p className="text-gray-500 text-sm mt-1">
                {isLogin
                  ? `Ingresa tus datos para continuar como ${roleLabel.toLowerCase()}`
                  : `Completa el formulario para registrarte como ${roleLabel.toLowerCase()}`}
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Register-only: name */}
              {!isLogin && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">
                    Nombre completo
                  </label>
                  <input
                    type="text"
                    required
                    value={form.name}
                    onChange={(e) => handleField('name', e.target.value)}
                    placeholder="Ej. María González"
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#1E3A8A]/30 focus:border-[#1E3A8A] transition-all bg-gray-50 focus:bg-white"
                  />
                </div>
              )}

              {/* Email */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">
                  Correo electrónico
                </label>
                <input
                  type="email"
                  required
                  value={form.email}
                  onChange={(e) => handleField('email', e.target.value)}
                  placeholder={role === 'student' ? 'estudiante@universidad.edu' : 'docente@universidad.edu'}
                  className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#1E3A8A]/30 focus:border-[#1E3A8A] transition-all bg-gray-50 focus:bg-white"
                />
              </div>

              {/* Role-specific register fields */}
              {!isLogin && role === 'student' && (
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1.5">
                      Código estudiantil
                    </label>
                    <input
                      type="text"
                      value={form.studentId}
                      onChange={(e) => handleField('studentId', e.target.value)}
                      placeholder="Ej. 20231234"
                      className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#1E3A8A]/30 focus:border-[#1E3A8A] transition-all bg-gray-50 focus:bg-white"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1.5">
                      Carrera
                    </label>
                    <input
                      type="text"
                      value={form.career}
                      onChange={(e) => handleField('career', e.target.value)}
                      placeholder="Ej. Administración"
                      className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#1E3A8A]/30 focus:border-[#1E3A8A] transition-all bg-gray-50 focus:bg-white"
                    />
                  </div>
                </div>
              )}

              {!isLogin && role === 'teacher' && (
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1.5">
                      Institución
                    </label>
                    <input
                      type="text"
                      value={form.institution}
                      onChange={(e) => handleField('institution', e.target.value)}
                      placeholder="Ej. UNSA"
                      className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#1E3A8A]/30 focus:border-[#1E3A8A] transition-all bg-gray-50 focus:bg-white"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1.5">
                      Asignatura
                    </label>
                    <input
                      type="text"
                      value={form.subject}
                      onChange={(e) => handleField('subject', e.target.value)}
                      placeholder="Ej. Liderazgo"
                      className="w-full px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#1E3A8A]/30 focus:border-[#1E3A8A] transition-all bg-gray-50 focus:bg-white"
                    />
                  </div>
                </div>
              )}

              {/* Password */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">
                  Contraseña
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={form.password}
                    onChange={(e) => handleField('password', e.target.value)}
                    placeholder="••••••••"
                    className="w-full px-4 py-2.5 pr-11 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#1E3A8A]/30 focus:border-[#1E3A8A] transition-all bg-gray-50 focus:bg-white"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Confirm password (register only) */}
              {!isLogin && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">
                    Confirmar contraseña
                  </label>
                  <div className="relative">
                    <input
                      type={showConfirmPassword ? 'text' : 'password'}
                      required
                      value={form.confirmPassword}
                      onChange={(e) => handleField('confirmPassword', e.target.value)}
                      placeholder="••••••••"
                      className="w-full px-4 py-2.5 pr-11 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#1E3A8A]/30 focus:border-[#1E3A8A] transition-all bg-gray-50 focus:bg-white"
                    />
                    <button
                      type="button"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
                    >
                      {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              )}

              {/* Forgot password */}
              {isLogin && (
                <div className="flex justify-end">
                  <button type="button" className="text-[#1E3A8A] text-xs font-medium hover:underline">
                    ¿Olvidaste tu contraseña?
                  </button>
                </div>
              )}

              {/* Terms (register only) */}
              {!isLogin && (
                <div className="flex items-start gap-2.5 pt-1">
                  <input
                    type="checkbox"
                    required
                    id="terms"
                    className="mt-0.5 w-4 h-4 accent-[#1E3A8A] rounded"
                  />
                  <label htmlFor="terms" className="text-xs text-gray-500 leading-relaxed">
                    Acepto los{' '}
                    <span className="text-[#1E3A8A] font-medium cursor-pointer hover:underline">
                      términos y condiciones
                    </span>{' '}
                    y la{' '}
                    <span className="text-[#1E3A8A] font-medium cursor-pointer hover:underline">
                      política de privacidad
                    </span>
                  </label>
                </div>
              )}

              {/* Submit */}
              <button
                type="submit"
                className="w-full py-3 bg-[#1E3A8A] hover:bg-[#1a3278] text-white font-semibold rounded-xl transition-all flex items-center justify-center gap-2 mt-2 shadow-md hover:shadow-lg active:scale-95"
              >
                {isLogin ? 'Iniciar Sesión' : 'Crear Cuenta'}
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>

            {/* Divider */}
            <div className="flex items-center gap-3 my-5">
              <div className="flex-1 h-px bg-gray-100" />
              <span className="text-xs text-gray-400">o</span>
              <div className="flex-1 h-px bg-gray-100" />
            </div>

            {/* Toggle mode */}
            <p className="text-center text-sm text-gray-500">
              {isLogin ? '¿No tienes cuenta?' : '¿Ya tienes cuenta?'}{' '}
              <button
                type="button"
                onClick={() => setIsLogin(!isLogin)}
                className="text-[#1E3A8A] font-semibold hover:underline"
              >
                {isLogin ? 'Regístrate gratis' : 'Inicia sesión'}
              </button>
            </p>
          </div>

          {/* Role badge at bottom */}
          <div className="flex items-center justify-center gap-2 mt-5">
            <div className={`w-2 h-2 rounded-full ${role === 'student' ? 'bg-[#FACC15]' : 'bg-purple-400'}`} />
            <span className="text-xs text-gray-400">Modo {roleLabel}</span>
            <button
              onClick={() => setAuthMode('role-select')}
              className="text-xs text-[#1E3A8A] font-medium hover:underline ml-1"
            >
              Cambiar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
