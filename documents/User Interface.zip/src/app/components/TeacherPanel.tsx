import { Users, TrendingUp, FileText, Download, Filter } from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from './ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import { Progress } from './ui/progress';
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';

const studentsData = [
  {
    id: '1',
    name: 'Ana García Martínez',
    email: 'ana.garcia@universidad.edu',
    progress: 85,
    evaluations: 4,
    activities: 12,
    lastActivity: '2025-10-29',
    status: 'active',
  },
  {
    id: '2',
    name: 'Carlos Rodríguez López',
    email: 'carlos.rodriguez@universidad.edu',
    progress: 72,
    evaluations: 3,
    activities: 9,
    lastActivity: '2025-10-28',
    status: 'active',
  },
  {
    id: '3',
    name: 'María Fernández Silva',
    email: 'maria.fernandez@universidad.edu',
    progress: 95,
    evaluations: 5,
    activities: 15,
    lastActivity: '2025-10-30',
    status: 'active',
  },
  {
    id: '4',
    name: 'Juan Pérez González',
    email: 'juan.perez@universidad.edu',
    progress: 45,
    evaluations: 2,
    activities: 5,
    lastActivity: '2025-10-25',
    status: 'inactive',
  },
  {
    id: '5',
    name: 'Laura Sánchez Ruiz',
    email: 'laura.sanchez@universidad.edu',
    progress: 68,
    evaluations: 3,
    activities: 8,
    lastActivity: '2025-10-29',
    status: 'active',
  },
];

const groupProgressData = [
  { week: 'Sem 1', promedio: 45 },
  { week: 'Sem 2', promedio: 58 },
  { week: 'Sem 3', promedio: 65 },
  { week: 'Sem 4', promedio: 73 },
];

const skillsAverages = [
  { skill: 'Liderazgo', promedio: 78 },
  { skill: 'Comunicación', promedio: 82 },
  { skill: 'Toma de Decisiones', promedio: 71 },
  { skill: 'Trabajo en Equipo', promedio: 85 },
  { skill: 'Gestión del Tiempo', promedio: 68 },
];

export function TeacherPanel() {
  const totalStudents = studentsData.length;
  const activeStudents = studentsData.filter(s => s.status === 'active').length;
  const averageProgress = Math.round(
    studentsData.reduce((sum, s) => sum + s.progress, 0) / totalStudents
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h2>Panel de Docente</h2>
          <p className="text-muted-foreground mt-1">
            Monitorea el progreso y desempeño de tus estudiantes
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <Filter className="w-4 h-4 mr-2" />
            Filtrar
          </Button>
          <Button className="bg-primary hover:bg-primary/90">
            <Download className="w-4 h-4 mr-2" />
            Exportar Reporte
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="p-5 shadow-md">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
              <Users className="w-6 h-6 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total Estudiantes</p>
              <p className="text-2xl">{totalStudents}</p>
            </div>
          </div>
        </Card>

        <Card className="p-5 shadow-md">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-accent" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Estudiantes Activos</p>
              <p className="text-2xl">{activeStudents}</p>
            </div>
          </div>
        </Card>

        <Card className="p-5 shadow-md">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-secondary/10 rounded-lg flex items-center justify-center">
              <FileText className="w-6 h-6 text-secondary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Progreso Promedio</p>
              <p className="text-2xl">{averageProgress}%</p>
            </div>
          </div>
        </Card>

        <Card className="p-5 shadow-md">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
              <FileText className="w-6 h-6 text-purple-600" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Evaluaciones Totales</p>
              <p className="text-2xl">{studentsData.reduce((sum, s) => sum + s.evaluations, 0)}</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="p-6 shadow-md">
          <h3 className="mb-4">Progreso Grupal</h3>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={groupProgressData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="week" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="promedio" stroke="#1E3A8A" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </Card>

        <Card className="p-6 shadow-md">
          <h3 className="mb-4">Promedio por Habilidad</h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={skillsAverages}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="skill" angle={-45} textAnchor="end" height={100} />
              <YAxis />
              <Tooltip />
              <Bar dataKey="promedio" fill="#FACC15" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* Students Table */}
      <Card className="shadow-md">
        <div className="p-6 border-b">
          <div className="flex items-center justify-between">
            <h3>Estudiantes</h3>
            <Select defaultValue="all">
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="active">Activos</SelectItem>
                <SelectItem value="inactive">Inactivos</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Estudiante</TableHead>
                <TableHead>Progreso</TableHead>
                <TableHead className="text-center">Evaluaciones</TableHead>
                <TableHead className="text-center">Actividades</TableHead>
                <TableHead>Última Actividad</TableHead>
                <TableHead>Estado</TableHead>
                <TableHead className="text-right">Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {studentsData.map((student) => (
                <TableRow key={student.id}>
                  <TableCell>
                    <div>
                      <p>{student.name}</p>
                      <p className="text-sm text-muted-foreground">{student.email}</p>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="w-32">
                      <div className="flex items-center gap-2 mb-1">
                        <Progress value={student.progress} className="h-2 flex-1" />
                        <span className="text-sm">{student.progress}%</span>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="text-center">{student.evaluations}</TableCell>
                  <TableCell className="text-center">{student.activities}</TableCell>
                  <TableCell className="text-sm">{student.lastActivity}</TableCell>
                  <TableCell>
                    <Badge variant={student.status === 'active' ? 'default' : 'secondary'}>
                      {student.status === 'active' ? 'Activo' : 'Inactivo'}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm">
                      Ver Detalles
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </Card>
    </div>
  );
}
